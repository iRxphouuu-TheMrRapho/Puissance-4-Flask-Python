var id = (new URLSearchParams(window.location.search)).get("id")
var shared_id = -1

function start() {
    var socket = io()
    
	socket.on('connect', function() {
        socket.emit('play', id);
    })

	socket.on('play', function(data) {
		console.log("play: ", data)
		var split = data.split("=")
		
		if(split[0] === "state"){
			if(split[1] === "0"){
				console.log("Invalid Id")
				window.location.href = "/"
			}else if(split[1] === "1"){
				console.log("Id OK")
			}
		}else if(split[0] === "shared_id"){
			shared_id = split[1]

            let text_element = document.getElementById('button')
            text_element.innerText = (window.location.href.split("=")[0] + "=" + shared_id)
		}else if(split[0] === "reload"){
			window.location.reload()
		}
    })
}