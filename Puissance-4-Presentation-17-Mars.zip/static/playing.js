let player_id = 0
let id = (new URLSearchParams(window.location.search)).get("id")
let socket = io()
let my_turn = false;
let has_played = false;
let end = false;

function start() {
	socket.on('connect', function() {
        socket.emit('playing', id);
    })

	socket.on('playing', function(data) {
		if(end)return;
		console.log("playing: ", data)
		let split = data.split("=")
		
		if(split[0] === "state"){
			if(split[1] === "0"){
				console.log("Invalid Id")
				window.location.href = "/"
			}else if(split[1] === "1"){
				console.log("Id OK")
			}
		}else if(split[0] == "map"){
			for(var x = 0; x < 7; x++){
				for(var y = 0; y < 6; y++){
					var n = split[1][y*6+x]
					
					if(n != 0){
						var row = document.getElementById("row"+(5-y))
						row.children[x].children[0].className = "flex w-4/5 h-4/5  transition player" + n + " ease-in-out delay-100 centered rounded-full"
					}
				}
			}
		}else if(split[0] === "player"){
			player_id = split[1]
		}else if(split[0] === "turn"){
			my_turn = split[1] === player_id
			if(split[1] === player_id){
				sendNormal("C'est a toi de jouer")
			}
		}
    })
	
	socket.on('playing2', function(data) {
		if(end)return;
		console.log("playing2: ", data)
		let split = data.split("=")
		
		if(split[0] === "player"){
			place2(split[2], split[1])
		}else if(split[0] === "turn"){
			my_turn = split[1] === player_id
			has_played = false;
			if(split[1] === player_id){
				sendNormal("C'est a toi de jouer !")
			}
		}else if(split[0] === "win"){
			end = true;
			if(split[1] === player_id){
				sendGood("Vous avez gagné la partie, Bravo !")
			}else{
				sendError("Vous avez perdu la partie !")
			}

			setTimeout(function () {
				const backButton = document.getElementById("backbutton")
				console.log(backButton)
				backButton.className = "mt-8 w-1/3 current transition ease-in-out delay-100 shadow-lg flex text-center bg-blue-600 hover:bg-blue-500 hover:scale-110 p-4 rounded-lg text-gray-50 text-xl font-medium tracking-widest"
			}, 3000)
		}
	})
}

function goBack(){
	window.location.href = "/"
}

function place(elem, column){
	if(my_turn === false){
		sendNormal("Ce n'est pas a toi de jouer !")
		return
	}
	if(has_played === true){
		sendNormal("Ce n'est pas a toi de jouer !")
		return
	}
	has_played = true;
	socket.emit('playing2', id + "=" + column);
}

function place2(column, player){
	for(let i = 5; i >= 0; i--){
		let row = document.getElementById("row"+i)
		if(row.children[column].firstChild.classList.contains("player0")){
			row.children[column].firstChild.classList.replace("player0", "player" + player)
			return
		}
	}   
}
let currentmsg = ""

function sendNormal(msg){
	sendMessage("bg-gray-100 text-gray-500", msg)
}

function sendGood(msg){
    sendMessage("bg-green-100 text-green-500", msg)
}

function sendError(msg){
    sendMessage("bg-red-100 text-red-500", msg)
}

function sendMessage(classToAdd, errmsg){
	let response_element = document.getElementById('response')
	console.log(response_element)
	response_element.className = "mt-8 flex text-2xl tracking-wide transition ease-in-out delay-100 justify-center rounded-lg flex-col p-4 shadow-lg " + classToAdd
	console.log(response_element)
    response_element.innerHTML = errmsg;
	currentmsg = errmsg;
	setTimeout(function(){
		clearMessage(errmsg)
	}, 3000)
}

function clearMessage(message){
	let response_element = document.getElementById('response')
	if(currentmsg === message || message === "@"){
		response_element.classList.add("hidden")
	}
}
