
const msg = "Vous avez copier le lien !"
const errmsg = "Erreur ! Vous avez déjà une demande / partie !"

function request() {
    axios.get(window.location.href + "create_game").then(
        (response) => {
            let result = response.data
            let address = window.location.href + "play?id=" + result
            window.location.href = address
        }
    );
}
